window.addEventListener('load', ()=> (
    document.querySelector('.intro__anim').classList.add('bounceIn')
))